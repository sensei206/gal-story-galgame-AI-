// 修复 index.html 中缺失的 </script> 闭合标签
const fs = require('fs');
const path = 'index.html';
let html = fs.readFileSync(path, 'utf8');
const lines = html.split('\n');

// 找到所有独立的 <script> 开标签行（模板字符串内的 <script> 出现在 2544 行附近且带缩进前缀，不影响前 6 个）
const opens = [];
lines.forEach((l, i) => { if (l.trim() === '<script>') opens.push(i); });
console.log('script open lines (0-based):', opens);

// 在第 2..n 个开标签之前补 </script>（从后往前插，避免行号偏移）
for (let k = opens.length - 1; k >= 1; k--) {
  lines.splice(opens[k], 0, '</script>');
}

let out = lines.join('\n');
// 清理多余的 </html>
const htmlTags = out.split('</html>').length - 1;
if (htmlTags > 1) out = out.replace(/<\/html>\s*<\/html>\s*$/, '</html>\n');
// 确保结尾有 </body></html>
if (!/<\/body>\s*<\/html>\s*$/.test(out)) {
  out = out.replace(/<\/html>\s*$/, '</body>\n</html>\n');
}

fs.writeFileSync(path, out);
console.log('fixed. </html> count:', out.split('</html>').length - 1);
