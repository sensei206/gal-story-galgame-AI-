// 冒烟测试 v2：分镜卡片模型。加载 index.html 全部 script 块（stub 浏览器 API）
const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('index.html', 'utf8');
const blocks = [];
const re = /<script>([\s\S]*?)<\/script>/g;
let m;
while ((m = re.exec(html)) !== null) blocks.push(m[1]);

const noopEl = () => ({
  addEventListener() {}, classList: { add() {}, remove() {}, toggle() {} },
  style: {}, dataset: {}, innerHTML: '', textContent: '', value: '', checked: false,
  appendChild() {}, querySelector() { return noopEl(); }, querySelectorAll() { return []; },
  getContext() { return { clearRect() {}, fillRect() {}, beginPath() {}, fill() {}, stroke() {},
    moveTo() {}, lineTo() {}, arc() {}, ellipse() {}, quadraticCurveTo() {}, strokeRect() {},
    roundRect() {}, createLinearGradient() { return { addColorStop() {} }; },
    createRadialGradient() { return { addColorStop() {} }; }, drawImage() {}, save() {}, restore() {},
    translate() {}, rotate() {}, fillStyle: '', strokeStyle: '', lineWidth: 1, globalAlpha: 1 } },
  getBoundingClientRect() { return { width: 0, height: 0 }; },
  click() {}, focus() {}, remove() {}, closest() { return null; }, setPointerCapture() {},
  files: [], width: 0, height: 0, clientWidth: 0, naturalWidth: 0, naturalHeight: 0
});
const sandbox = {
  console,
  window: {}, document: {
    addEventListener() {}, querySelector() { return noopEl(); }, querySelectorAll() { return []; },
    createElement() { return noopEl(); }, body: { appendChild() {}, style: {} },
    documentElement: { dataset: {} }, title: ''
  },
  localStorage: { getItem() { return null; }, setItem() {} },
  indexedDB: { open() { return { onupgradeneeded: null, onsuccess: null, onerror: null, result: { createObjectStore() {}, transaction() { return { get() { return { onsuccess: null, onerror: null }; }, put() { return {}; } }; } } }; } },
  setTimeout, clearTimeout, setInterval, clearInterval, alert() {}, confirm() { return true; }, prompt() { return ''; },
  URL: { createObjectURL() { return ''; }, revokeObjectURL() {} },
  Blob, FileReader: function () { this.readAsDataURL = () => {}; this.readAsText = () => {}; },
  Image: function () { this.onload = null; this.onerror = null; },
  Audio: function () { this.play = () => Promise.resolve(); this.pause = () => {}; },
  AudioContext: function () {}, OfflineAudioContext: function () {},
  atob: s => Buffer.from(s, 'base64').toString('binary'),
  btoa: s => Buffer.from(s, 'binary').toString('base64'),
  matchMedia: () => ({ matches: false }),
  fetch: () => Promise.reject(new Error('no network in smoke')),
  navigator: {}
};
sandbox.window = sandbox;
vm.createContext(sandbox);
try {
  for (const b of blocks) vm.runInContext(b, sandbox, { timeout: 5000 });
} catch (e) { console.error('BLOCK EXEC FAIL:', e.message); process.exit(1); }

const App = vm.runInContext('App', sandbox);
const P = vm.runInContext('P', sandbox);
const defaultProject = vm.runInContext('defaultProject', sandbox);
const linesToCards = vm.runInContext('linesToCards', sandbox);
const migrateProject = vm.runInContext('migrateProject', sandbox);
const chordNotes = vm.runInContext('chordNotes', sandbox);
const bufferToWavDataUrl = vm.runInContext('bufferToWavDataUrl', sandbox);
const buildPlayerHtml = vm.runInContext('buildPlayerHtml', sandbox);

let pass = 0, fail = 0;
const ok = (cond, name) => { if (cond) { pass++; console.log('  ✓ ' + name); } else { fail++; console.log('  ✗ ' + name); } };

console.log('\n[1] 默认项目 + 演示项目卡片模型');
const p = defaultProject();
ok(p.scenes.length === 0 && p.characters.length === 0, '默认项目无预设场景与角色（全新开始）');
ok(p.assets.length === 0, '默认项目无内置素材');
// 构造演示项目验证卡片模型
const demo = {
  title: '演示', startSceneId: 'x1',
  characters: [{ id: 'c1', name: '凛', color: '#e88cb0', sprites: [{ id: 'sp1', name: '默认', dataUrl: 'data:image/png;base64,AAAA' }] }],
  assets: [{ id: 'a1', kind: 'bg', name: '背景', dataUrl: 'data:image/jpeg;base64,BBB' }, { id: 'a2', kind: 'bgm', name: 'BGM', dataUrl: 'data:audio/wav;base64,CCC' }],
  scenes: [{
    id: 'x1', name: '测试场景', cards: [
      { id: 'c1', bg: 'a1', lines: [{ id: 'l1', speaker: '', text: '旁白' }], sprites: [], bgm: '', sfx: '', choices: [], end: false },
      { id: 'c2', bg: 'a1', lines: [{ id: 'l2', speaker: 'c1', text: '一' }, { id: 'l3', speaker: 'c1', text: '二' }], sprites: [{ id: 's1', charId: 'c1', spriteId: 'sp1', x: 50, y: 0, scale: 1 }], bgm: 'a2', sfx: '', choices: [{ text: '去结局', target: 'x2' }], end: false },
      { id: 'c3', bg: 'a1', lines: [], sprites: [], bgm: '', sfx: '', choices: [], end: true, endText: '结局' }
    ]
  }, { id: 'x2', name: '第二场景', cards: [{ id: 'c4', bg: 'a1', lines: [{ id: 'l4', speaker: '', text: '第二个场景' }], sprites: [], bgm: '', sfx: '', choices: [], end: false }] }]
};
ok(demo.scenes[0].cards.length === 3, '演示项目 3 张卡');
ok(demo.scenes[0].cards[1].lines.length === 2, '多段话结构正确');
ok(demo.scenes[0].cards[1].choices[0].target === 'x2', '分支目标存在');
const assetIds = new Set(demo.assets.map(a => a.id));
const refs = [];
demo.scenes.forEach(s => s.cards.forEach(c => { if (c.bg) refs.push(c.bg); if (c.bgm) refs.push(c.bgm); }));
ok(refs.every(r => assetIds.has(r)), '引用完整');
ok(demo.scenes[0].cards[1].sprites[0].charId === 'c1', '立绘引用角色');
ok(demo.scenes[0].cards[2].end === true, '结局卡');

console.log('\n[2] 旧数据迁移（lines → cards）');
const legacy = { scenes: [{ id: 'x1', name: '旧场景', lines: [
  { type: 'background', assetId: 'a1' },
  { type: 'dialogue', charId: 'c1', text: '你好' },
  { type: 'sprite', charId: 'c1', pos: 'center' },
  { type: 'choice', choices: [{ text: '走', target: 'scene:x1' }, { text: '留', target: '' }] },
  { type: 'wait', sec: 2 },
  { type: 'end', text: '结局' }
] }] };
const cards = linesToCards(legacy.scenes[0].lines);
ok(cards.length === 2, '6 步骤迁移为 2 张卡（背景卡 + 对话卡），实际 ' + cards.length);
ok(cards[0].bg === 'a1', 'background → 背景卡');
ok(cards[1].lines.length === 1 && cards[1].lines[0].speaker === 'c1' && cards[1].sprites.length === 1 && cards[1].sprites[0].x === 50, '对话+立绘合并正确（center→x=50）');
ok(cards[1].choices.length === 2 && cards[1].choices[0].target === 'x1', '选项 target 去除 scene: 前缀');
ok(cards[1].end === true && cards[1].endText === '结局', 'end 迁移正确');
// v2 卡（text/speaker）→ v3 lines
const v2 = { scenes: [{ id: 'z1', name: 'v2', cards: [{ id: 'z1c1', bg: 'a1', text: '你好', speaker: 'c1', sprites: [], choices: [] }] }] };
ok(migrateProject(v2) === true, 'v2 卡迁移触发');
ok(v2.scenes[0].cards[0].lines.length === 1 && v2.scenes[0].cards[0].lines[0].text === '你好' && !('text' in v2.scenes[0].cards[0]), 'v2 卡 text/speaker → lines');
// wait 与 dialogue 分卡
const legacy2 = { scenes: [{ id: 'y1', lines: [{ type: 'dialogue', charId: 'c1', text: '一' }, { type: 'dialogue', charId: 'c1', text: '二' }, { type: 'wait', sec: 3 }] }] };
const cards2 = linesToCards(legacy2.scenes[0].lines);
ok(cards2.length === 2 && cards2[0].lines[0].text === '一' && cards2[1].lines[0].text === '二' && cards2[1].duration === 3, '连续对话分卡 + wait→时长，实际 ' + cards2.length + ' 卡');

console.log('\n[3] 和声与 WAV');
const ch = chordNotes('minor', 0, 1);
ok(ch[0] === 69, 'A 小调 i 和弦根音 A4(69)');
const fakeBuf = { numberOfChannels: 1, sampleRate: 22050, length: 100, getChannelData: () => new Float32Array(100).fill(0.1) };
const wav = bufferToWavDataUrl(fakeBuf);
const wavBin = Buffer.from(wav.split(',')[1], 'base64');
ok(wavBin.slice(0, 4).toString() === 'RIFF' && wavBin.length === 244, 'WAV 头与长度正确');

console.log('\n[4] 播放器（卡片驱动）');
P.state = { data: demo, sceneId: 'x1', cardIdx: 0, slots: {}, opts: {} };
P.clearStage = () => {};
const scene1 = P.findScene('x1');
ok(scene1.cards.length === 3, '演示场景 3 张卡');
ok(scene1.cards[1].lines.length === 2 && scene1.cards[1].choices[0].target === 'x2', '多段话与分支目标正确');
ok(P.run && typeof P.exec === 'function' && typeof P.askChoice === 'function' && typeof P.waitVideoEnd === 'function', '播放器核心方法存在');
P.state.ended = true;

console.log('\n[5] 导出 HTML（卡片模型）');
App.project = demo;
const htmlOut = buildPlayerHtml();
ok(htmlOut.includes('P.boot(') && htmlOut.includes('player-sprite-free'), '导出含启动与自由立绘样式');
ok(htmlOut.includes('"cards"'), '导出数据含 cards');
ok(!/<script>/.test(htmlOut.slice(htmlOut.indexOf('P.boot'))), '数据 JSON 内无裸 <script>');

console.log('\n[6] 导入弹窗运行时调用（回归 isAudio 残留 bug）');
try {
  vm.runInContext('openImportModal()', sandbox, { timeout: 2000 });
  vm.runInContext('openImportModal(\'video\')', sandbox, { timeout: 2000 });
  ok(true, 'openImportModal() 与 openImportModal(\'video\') 均不抛异常');
} catch (e) { ok(false, 'openImportModal 抛异常: ' + e.message); }

try {
  vm.runInContext('doImport([], \'bgm\', null)', sandbox, { timeout: 2000 });
  ok(true, 'doImport 空文件不抛异常');
} catch (e) { ok(false, 'doImport 抛异常: ' + e.message); }

const parseScript = vm.runInContext('parseScript', sandbox);

console.log('\n[6] 剧本模式 · 自动分镜');
const src = `【场景】黄昏的教室
旁白：放学后的教学楼安静得能听见风。
凛：真是的，又是你最后一个离开教室。
凛：不过……今天留下来，是有话想对你说。
【选项】
留下来听她说 -> 樱花树下
假装没听见 -> 走廊
【场景】樱花树下
旁白：第二天放学，你们约在操场边的樱花树下。
凛：太好了。那，从今天起，我们一起回家吧。
【结局】结局·樱色信笺`;
const sc = parseScript(src);
ok(sc.length === 2, '解析出 2 个场景');
ok(sc[0].name === '黄昏的教室' && sc[1].name === '樱花树下', '场景名正确');
ok(sc[0].cards.length === 2, '场景1 两张卡（旁白卡 + 凛对话&选项卡），实际 ' + sc[0].cards.length);
ok(sc[0].cards[0].lines.length === 1 && sc[0].cards[0].lines[0].speaker === '', '旁白单独成卡');
ok(sc[0].cards[1].lines.length === 2 && sc[0].cards[1].lines[0].speaker === '凛', '同角色连续台词合并为一张卡多段话');
ok(sc[0].cards[1].choices.length === 2, '选项解析为 2 个');
ok(sc[1].cards.some(c => c.end && c.endText === '结局·樱色信笺'), '结局解析正确');
const t1 = sc[0].cards[1].choices[0].target;
const t2 = sc[0].cards[1].choices[1].target;
ok(sc.some(s => s.id === t1) && t2 === '', '选项映射：存在的场景→id，不存在的→空（下一张卡）');
const bare = parseScript(['你好', '世界'].join(String.fromCharCode(10)));
ok(bare.length === 1 && bare[0].cards.length === 1 && bare[0].cards[0].lines.length === 2, '无角色前缀的纯文本合并为旁白多段话');

const parseStory = vm.runInContext('parseStory', sandbox);

console.log('\n[7] 自由故事智能分镜');
const story = ['黄昏的教室里，她终于鼓起勇气。“我喜欢你，从高一那年的樱花树下开始。”她低着头说。', '窗外的风轻轻吹过，樱花落了一地。'].join('\n\n');
const st = parseStory(story);
ok(st.cards.length === 3, '段落分镜：旁白/对话/旁白 3 张卡，实际 ' + st.cards.length);
ok(st.cards[1].lines[0].speaker === '她' && st.cards[1].lines[0].text.includes('我喜欢你'), '对话识别：说话人「她」+ 引号内台词');
ok(st.cards[0].lines[0].speaker === '' && st.cards[2].lines[0].speaker === '', '旁白卡识别正确');
ok(st.speakers.includes('她'), '说话人列表包含「她」');
const st2 = parseStory('“早。”凛说。“早啊。”她也笑着回应。凛又说：“今天天气不错。”');
ok(st2.cards.length === 3, '说话人变化自动分卡，实际 ' + st2.cards.length);
ok(st2.cards[0].lines[0].speaker === '凛' && st2.cards[1].lines[0].speaker === '她' && st2.cards[2].lines[0].speaker === '凛', '凛→她→凛 说话人识别正确');
const st3 = parseStory('他站在门口，轻轻敲了敲门。“有人吗？”他问。屋里没有人回答。');
ok(st3.cards.length === 3, '第三人称代词对话也能识别分镜，实际 ' + st3.cards.length);

const parseAiResult = vm.runInContext('parseAiResult', sandbox);

console.log('\n[8] AI 分镜结果解析');
const aiRaw = JSON.stringify({
  scenes: [
    { name: '黄昏', cards: [
      { lines: [{ speaker: '', text: '旁白' }, { speaker: '凛', text: '台词' }], choices: [{ text: '走', target: '雨夜' }], end: false, endText: '' },
      { lines: [], choices: [], end: true, endText: '结局·雨夜' }
    ] },
    { name: '雨夜', cards: [{ lines: [{ speaker: '凛', text: '再见' }], choices: [], end: false, endText: '' }] }
  ],
  characters: [{ name: '凛', role: '主角' }]
});
const ai = parseAiResult(aiRaw);
ok(ai.scenes.length === 2 && ai.scenes[0].name === '黄昏', 'AI 场景解析正确');
ok(ai.scenes[0].cards[0].lines.length === 2, 'AI 卡片多段话');
ok(ai.scenes[0].cards[0].choices[0].target === ai.scenes[1].id, 'AI 选项映射到场景 id');
ok(ai.scenes[0].cards[1].end === true, 'AI 结局卡');
ok(ai.characters.length === 1 && ai.characters[0].name === '凛', 'AI 角色列表');
// 主角"我"自动补齐
const ai2 = parseAiResult(JSON.stringify({ scenes: [{ name: 's', cards: [{ lines: [{ speaker: '我', text: '我来了' }, { speaker: '凛', text: '你终于来了' }], choices: [], end: false, endText: '' }] }], characters: [{ name: '凛', role: '主角' }] }));
ok(ai2.characters.some(c => c.name === '我' && c.role === '主角'), '主角“我”自动创建为角色');
ok(ai2.characters.filter(c => c.name === '凛').length === 1, '声明角色不重复创建');
// 播放器按名字也能找到角色（剧本模式 speaker 存名字）
P.state = { data: ai2, sceneId: 's', cardIdx: 0, slots: {}, opts: {} };
ok(P.findChar('凛') && P.charName('凛') === '凛', '播放器支持按角色名查找');
ok(P.findChar('我') && P.charName('我') === '我', '播放器支持主角“我”');
ok(parseAiResult('```json\n' + aiRaw + '\n```').scenes.length === 2, 'markdown 代码块包裹也能解析');
ok(parseAiResult('好的，以下是结果：' + aiRaw + '——请查收').scenes.length === 2, '前后附带文字也能解析');
let threw = false;
try { parseAiResult('不是 JSON'); } catch (e) { threw = true; }
ok(threw, '非法内容抛出错误');

console.log('\n[9] BGM 区间播放');
const resolveBgm = vm.runInContext('P.resolveBgm', sandbox);
const scBgm = { bgmTracks: [{ assetId: 'b1', from: 2, to: 4 }] };
ok(resolveBgm(scBgm, { bgm: '' }, 1).action === 'none', '第 1 卡：区间外无 BGM');
ok(resolveBgm(scBgm, { bgm: '' }, 2).action === 'play' && resolveBgm(scBgm, { bgm: '' }, 2).assetId === 'b1', '第 2 卡：命中区间开始播放');
ok(resolveBgm(scBgm, { bgm: '' }, 4).assetId === 'b1', '第 4 卡：区间内持续播放');
ok(resolveBgm(scBgm, { bgm: '' }, 5).action === 'none', '第 5 卡：离开区间自动停止');
ok(resolveBgm(scBgm, { bgm: '__stop__' }, 3).action === 'stop', '单卡「停止 BGM」优先于区间');
ok(resolveBgm(scBgm, { bgm: 'b2' }, 3).assetId === 'b2', '单卡指定 BGM 优先于区间');
const scBgm2 = { bgmTracks: [{ assetId: 'b1', from: 1, to: 1 }, { assetId: 'b2', from: 3, to: 3 }] };
ok(resolveBgm(scBgm2, { bgm: '' }, 1).assetId === 'b1' && resolveBgm(scBgm2, { bgm: '' }, 2).action === 'none' && resolveBgm(scBgm2, { bgm: '' }, 3).assetId === 'b2', '多个区间互不干扰（1 卡播 b1，3 卡播 b2）');

console.log(`\n结果: ${pass} 通过, ${fail} 失败`);
process.exit(fail ? 1 : 0);
