# -*- coding: utf-8 -*-
"""下载 Seedream 生成的示例素材并处理成工具内置资源。
- 立绘: 白底抠图 -> 透明 PNG
- 背景: 缩放 -> 16:9 JPG
用法: python scripts/fetch_assets.py <sprite_url> <bg_url>
"""
import io
import sys
import urllib.request
from PIL import Image

SPRITE_URL, BG_URL = sys.argv[1], sys.argv[2]


def download(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    return urllib.request.urlopen(req, timeout=60).read()


def cut_white(img: Image.Image, thr=246, feather=18):
    """把接近白色的像素变成透明, 边缘做羽化, 并裁剪透明边缘。"""
    img = img.convert("RGBA")
    px = img.load()
    w, h = img.size
    # 亮度 = max(r,g,b), 白度 = 1 - (max-min)/max
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            mx, mn = max(r, g, b), min(r, g, b)
            if mx >= thr and (mx - mn) <= 22:
                alpha = max(0, int(255 * (mx - thr) / (255 - thr)))
                # 带一点羽化
                if alpha < feather:
                    alpha = int(alpha * alpha / feather)
                px[x, y] = (r, g, b, alpha)
    bbox = img.getbbox()
    if bbox:
        img = img.crop(bbox)
    return img


def main():
    print("downloading sprite...")
    sprite = Image.open(io.BytesIO(download(SPRITE_URL)))
    sprite = cut_white(sprite)
    if sprite.height > 1400:
        sprite = sprite.resize(
            (int(sprite.width * 1400 / sprite.height), 1400), Image.LANCZOS
        )
    sprite.save("assets/hero-sprite.png", optimize=True)
    print("sprite -> assets/hero-sprite.png", sprite.size)

    print("downloading bg...")
    bg = Image.open(io.BytesIO(download(BG_URL))).convert("RGB")
    if bg.width > 1680:
        bg = bg.resize((1680, int(bg.height * 1680 / bg.width)), Image.LANCZOS)
    bg.save("assets/bg-campus.jpg", quality=86, optimize=True)
    print("bg -> assets/bg-campus.jpg", bg.size)


if __name__ == "__main__":
    main()
