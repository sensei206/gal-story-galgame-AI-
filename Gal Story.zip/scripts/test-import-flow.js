// 模拟导入→应用到卡片→渲染编辑器 全流程，检查右侧编辑器 HTML 是否含图
const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync('index.html', 'utf8');
const blocks = [];
const re = /<script>([\s\S]*?)<\/script>/g;
let m;
while ((m = re.exec(html)) !== null) blocks.push(m[1]);

// 可记录 innerHTML 的迷你元素
function makeEl(id) {
  const el = {
    id, _html: '', textContent: '', value: '', checked: false, style: {}, dataset: {},
    _children: [],
    set innerHTML(v) { this._html = v; },
    get innerHTML() { return this._html; },
    addEventListener() {}, classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    querySelector() { return makeEl('inner'); },
    querySelectorAll() { return []; },
    appendChild() {}, getContext() { return ctx2d(); }, remove() {}, closest() { return null; },
    play() { return Promise.resolve(); }, pause() {},
    getBoundingClientRect() { return { width: 800, height: 450, left: 0, top: 0, right: 800, bottom: 450 }; },
    setPointerCapture() {}, files: [], clientWidth: 800, width: 800, height: 450
  };
  return el;
}
function ctx2d() {
  return { clearRect() {}, fillRect() {}, beginPath() {}, fill() {}, stroke() {}, moveTo() {}, lineTo() {},
    arc() {}, ellipse() {}, quadraticCurveTo() {}, strokeRect() {}, roundRect() {},
    createLinearGradient() { return { addColorStop() {} }; }, createRadialGradient() { return { addColorStop() {} }; },
    drawImage() {}, save() {}, restore() {}, translate() {}, rotate() {}, fillStyle: '', strokeStyle: '', lineWidth: 1, globalAlpha: 1 };
}
const elements = {};
const getEl = id => elements[id] || (elements[id] = makeEl(id));
const sandbox = {
  console,
  window: {},
  document: {
    addEventListener() {},
    querySelector(sel) { return getEl(String(sel).replace(/^#/, '')); },
    querySelectorAll() { return []; },
    createElement() { return makeEl('created'); },
    body: { appendChild() {}, style: {} }, documentElement: { dataset: {} }, title: ''
  },
  localStorage: { getItem() { return null; }, setItem() {} },
  indexedDB: { open() { return { onupgradeneeded: null, onsuccess: null, onerror: null, result: { createObjectStore() {}, transaction() { return { get() { return { onsuccess: null, onerror: null }; }, put() { return {}; } }; } } }; } },
  setTimeout, clearTimeout, setInterval, clearInterval, alert() {}, confirm() { return true; }, prompt() { return ''; },
  URL: { createObjectURL() { return ''; }, revokeObjectURL() {} },
  Blob, FileReader: function () { this.readAsDataURL = () => {}; this.readAsText = () => {}; },
  Image: function () { this.onload = null; this.onerror = null; },
  Audio: function () { this.play = () => Promise.resolve(); this.pause = () => {}; },
  AudioContext: function () {}, OfflineAudioContext: function () {},
  atob: s => Buffer.from(s, 'base64').toString('binary'),
  btoa: s => Buffer.from(s, 'binary').toString('base64'),
  matchMedia: () => ({ matches: false }),
  fetch: () => Promise.reject(new Error('no network')),
  navigator: {}
};
sandbox.window = sandbox;
vm.createContext(sandbox);
try { for (const b of blocks) vm.runInContext(b, sandbox, { timeout: 5000 }); }
catch (e) { console.error('BLOCK EXEC FAIL:', e.message); process.exit(1); }

let pass = 0, fail = 0;
const ok = (c, n) => { c ? pass++ : fail++; console.log((c ? '  ✓ ' : '  ✗ ') + n); };

console.log('[导入→应用→渲染 全流程]');
// 准备项目：默认项目为空，构造一个测试场景并选中第一张卡
vm.runInContext(`
  App.project = defaultProject();
  migrateProject(App.project);
  App.project.scenes.push({ id: 't1', name: '测试', cards: [{ id: 'tc1', bg: '', lines: [], sprites: [], choices: [], end: false }] });
  curSceneId = 't1';
  curCardId = 'tc1';
`, sandbox);

// 1) 模拟 addAsset 一张导入的图片
const a = vm.runInContext(`addAsset({ kind: 'bg', name: '测试背景', dataUrl: 'data:image/jpeg;base64,AAAA' })`, sandbox);
ok(a && a.id, '导入素材入库成功, id=' + (a && a.id));

// 2) 应用为当前卡片背景
vm.runInContext('applyImportedBg(' + JSON.stringify(a) + ')', sandbox);
const card = vm.runInContext(`App.project.scenes[0].cards.find(x => x.id === curCardId)`, sandbox);
ok(card.bg === a.id, '当前卡片背景已设为导入素材');

// 3) 渲染卡片编辑器，检查 HTML 输出
vm.runInContext('renderCardEditor()', sandbox);
const editorHtml = elements['cardEditor']._html;
ok(editorHtml.includes('data:image/jpeg;base64,AAAA'), '编辑器背景框包含图片 img');
ok(/sc-bg[\s\S]*?background-image:url\('data:image\/jpeg;base64,AAAA'\)/.test(editorHtml), '立绘画布 sc-bg 含背景图');
ok(editorHtml.includes('测试背景'), '背景框显示素材名');

// 4) 视频素材场景
const v = vm.runInContext(`addAsset({ kind: 'video', name: '测试视频', dataUrl: 'data:video/mp4;base64,BBBB' })`, sandbox);
vm.runInContext('applyImportedBg(' + JSON.stringify(v) + ')', sandbox);
vm.runInContext('renderCardEditor()', sandbox);
const editorHtml2 = elements['cardEditor']._html;
ok(editorHtml2.includes('data:video/mp4;base64,BBBB'), '视频素材背景框包含 video 元素');

console.log(`\n结果: ${pass} 通过, ${fail} 失败`);
process.exit(fail ? 1 : 0);
