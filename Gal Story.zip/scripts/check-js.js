// 提取 index.html 中所有 <script> 块并做语法检查
const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const re = /<script>([\s\S]*?)<\/script>/g;
let m, i = 0, fail = 0;
while ((m = re.exec(html)) !== null) {
  i++;
  const code = m[1];
  try {
    new Function(code);
    console.log(`[OK] script block #${i} (${code.length} chars)`);
  } catch (e) {
    fail++;
    console.log(`[FAIL] script block #${i}: ${e.message}`);
    // 打印出错位置附近
    const lines = code.split('\n');
    const lineMatch = /line (\d+)/.exec(e.message);
    if (lineMatch) {
      const ln = Number(lineMatch[1]);
      console.log('  near: ' + lines.slice(Math.max(0, ln - 3), ln + 2).join('\n  | '));
    }
  }
}
console.log(`\n${i} blocks checked, ${fail} failed`);
process.exit(fail ? 1 : 0);
