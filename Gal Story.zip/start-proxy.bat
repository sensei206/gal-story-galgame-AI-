@echo off
cd /d "%~dp0"
title Gal Story ��ͼ����

REM ===== 1. port check: skip if already running =====
netstat -ano | findstr /r /c:":8123 .*LISTENING" >nul 2>nul
if not errorlevel 1 (
    echo [INFO] proxy is already running - port 8123 listening.
    echo        if AI storyboard still fails, refresh the page and retry.
    echo.
    pause
    exit /b 0
)

REM ===== 2. locate python =====
if not exist "%~dp0proxy.py" (
    echo [ERROR] proxy.py not found in this folder.
    echo        do NOT copy this bat elsewhere - double-click it inside
    echo        the Gal Story project folder next to proxy.py.
    echo.
    pause
    exit /b 1
)

set "PYEXE="
REM 优先从 PATH 找 python（不依赖任何本机专属路径，可移植）
for /f "delims=" %%i in ('where python 2^>nul') do (
    if not defined PYEXE set "PYEXE=%%i"
)
REM 常见 Python 安装位置兜底
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYEXE if exist "C:\Python311\python.exe" set "PYEXE=C:\Python311\python.exe"
if not defined PYEXE if exist "C:\Python312\python.exe" set "PYEXE=C:\Python312\python.exe"
if not defined PYEXE if exist "C:\Python313\python.exe" set "PYEXE=C:\Python313\python.exe"
if not defined PYEXE (
    echo [ERROR] python not found.
    echo        install python 3 from python.org, or tell me your python.exe path.
    echo.
    pause
    exit /b 1
)

echo ============================================
echo   Gal Story Proxy is starting...
echo   keep this window open = proxy running
echo   close this window    = stop proxy
echo   python: %PYEXE%
echo ============================================
echo.

"%PYEXE%" proxy.py

echo.
echo proxy exited. if you see an error above, send it to me.
pause
