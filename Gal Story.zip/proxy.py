#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gal Story 本地生图代理
=====================
把浏览器里的 AI 文生图请求转发到 AutoGLM Seedream 接口：
自动获取 token、生成签名头、下载生成的图片并转成 dataURL 返回，
同时附带 CORS 头，让网页工具可直接调用。

用法:
    python proxy.py            # 监听 127.0.0.1:8123
    python proxy.py 9000       # 自定义端口

端点:
    GET  /get_token            -> 透传 AutoGLM 本地 token 服务
    POST /generate-image       -> {"query": "..."} -> {"code":0,"data":{"image_url":"data:..."}}
    POST /ai-script            -> {"text","apiKey"} -> 转发 DeepSeek 智能分镜，返回 {"code":0,"data":"<AI JSON>"}

在工具的「图片工坊 -> AI 文生图」面板中填入端点:
    http://127.0.0.1:8123/generate-image
"""
import base64
import hashlib
import io
import json
import sys
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

TOKEN_URL_DEFAULT = "http://127.0.0.1:18432/get_token"
# ===== 密钥配置（分离自工程文件，别人拿到后填自己的） =====
# 读取优先级: 环境变量 > config.json > 默认值
import os
import json as _json
_CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
_cfg = {}
try:
    with open(_CONFIG_FILE, encoding="utf-8") as _f:
        _cfg = _json.load(_f)
except Exception:
    pass
SECRET = os.environ.get("KOISTORY_SEEDREAM_SECRET") or _cfg.get("seedream_secret") or ""
TOKEN_URL = os.environ.get("KOISTORY_TOKEN_URL") or _cfg.get("token_url") or TOKEN_URL_DEFAULT
# 生图后端: auto(自动) | autoglm(默认,需 AutoClaw) | zhipu(智谱开放平台,免 AutoClaw)
IMAGE_BACKEND = _cfg.get("image_backend", "auto")
ZHIPU_API_KEY = os.environ.get("KOISTORY_ZHIPU_API_KEY") or _cfg.get("zhipu_api_key") or ""
ZHIPU_URL = "https://open.bigmodel.cn/api/paas/v4/images/generations"
ZHIPU_MODEL = _cfg.get("zhipu_model", "cogview-4")
SEEDREAM_URL = "https://autoglm-api.zhipuai.cn/agentdr/v1/assistant/skills/generate-image-seedream"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"
DEEPSEEK_MODEL = "deepseek-chat"
APPID = "100003"
UA = "Mozilla/5.0 (Gal Story Proxy)"


def http_get(url, headers=None, timeout=30):
    req = urllib.request.Request(url, headers=headers or {"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(), r.status


def http_post_json(url, payload, headers, timeout=120):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(), r.status


def fetch_token():
    raw, _ = http_get(TOKEN_URL, timeout=10)
    token = raw.decode("utf-8", "ignore").strip()
    if not token.startswith("Bearer "):
        token = "Bearer " + token
    return token


def sign_headers():
    ts = str(int(time.time()))
    sign = hashlib.md5(f"{APPID}&{ts}&{SECRET}".encode()).hexdigest()
    return {
        "X-Auth-Appid": APPID,
        "X-Auth-TimeStamp": ts,
        "X-Auth-Sign": sign,
        "Content-Type": "application/json",
    }


def token_service_ok():
    try:
        http_get(TOKEN_URL, timeout=2)
        return True
    except Exception:
        return False

def zhipu_image(query, api_key):
    headers = {"Authorization": "Bearer " + api_key, "Content-Type": "application/json"}
    body = {"model": ZHIPU_MODEL, "prompt": query, "size": "1024x1024"}
    resp, status = http_post_json(ZHIPU_URL, body, headers, timeout=180)
    j = json.loads(resp.decode("utf-8", "ignore"))
    if not j.get("data") or not j["data"]:
        raise RuntimeError("智谱生图错误: " + str(j.get("error", j)))
    url = j["data"][0]["url"]
    img_bytes, _ = http_get(url, timeout=60)
    mime = "image/png"
    if img_bytes[:3] == b"\xff\xd8\xff":
        mime = "image/jpeg"
    return {"code": 0, "data": {"image_url": "data:" + mime + ";base64," + base64.b64encode(img_bytes).decode()}}

def generate_image(query, zhipu_key=None):
    eff_key = zhipu_key or ZHIPU_API_KEY
    use_zhipu = IMAGE_BACKEND == "zhipu" or (IMAGE_BACKEND == "auto" and eff_key and not token_service_ok())
    if use_zhipu:
        if not eff_key:
            raise RuntimeError("未配置智谱 API Key：可在工具「服务设置」或 config.json 填写")
        return zhipu_image(query, eff_key)
    if not SECRET:
        raise RuntimeError(
            "未配置 Seedream 签名密钥：请在工程目录的 config.json 中填写 seedream_secret，"
            "或设置环境变量 KOISTORY_SEEDREAM_SECRET"
        )
    token = fetch_token()
    headers = sign_headers()
    headers["Authorization"] = token
    body, status = http_post_json(SEEDREAM_URL, {"query": query}, headers)
    resp = json.loads(body.decode("utf-8", "ignore"))
    if resp.get("code") != 0:
        raise RuntimeError(f"Seedream 错误: {resp.get('msg')}")
    url = resp["data"]["image_url"]
    img_bytes, _ = http_get(url, timeout=60)
    mime = "image/png"
    # 简单按文件头猜测类型（jpg 最常见）
    if img_bytes[:3] == b"\xff\xd8\xff":
        mime = "image/jpeg"
    elif img_bytes[:8] == b"\x89PNG\r\n\x1a\n":
        mime = "image/png"
    data_url = "data:" + mime + ";base64," + base64.b64encode(img_bytes).decode()
    return {"code": 0, "msg": "SUCCESS", "data": {"image_url": data_url}}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

    def _json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        if self.path.split("?")[0] == "/get_token":
            try:
                raw, _ = http_get(TOKEN_URL, timeout=10)
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self._cors()
                self.end_headers()
                self.wfile.write(raw)
            except Exception as e:
                self._json({"code": 1, "msg": f"token 服务不可达: {e}"}, 502)
        else:
            self._json({"code": 1, "msg": "not found"}, 404)

    def do_POST(self):
        path = self.path.split("?")[0]
        if path not in ("/generate-image", "/ai-script"):
            self._json({"code": 1, "msg": "not found"}, 404)
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            payload = json.loads(self.rfile.read(length).decode("utf-8", "ignore"))
            if path == "/generate-image":
                query = str(payload.get("query", "")).strip()
                if not query:
                    self._json({"code": 1, "msg": "query 不能为空"}, 400)
                    return
                t0 = time.time()
                result = generate_image(query, str(payload.get("zhipuApiKey", "")).strip())
                result["time_ms"] = int((time.time() - t0) * 1000)
                self._json(result)
            else:
                text = str(payload.get("text", "")).strip()
                api_key = str(payload.get("apiKey", "")).strip()
                system = str(payload.get("systemPrompt", ""))
                model = str(payload.get("model", DEEPSEEK_MODEL))
                if not text:
                    self._json({"code": 1, "msg": "text 不能为空"}, 400)
                    return
                if not api_key:
                    self._json({"code": 1, "msg": "缺少 DeepSeek API Key"}, 400)
                    return
                headers = {"Authorization": "Bearer " + api_key, "Content-Type": "application/json"}
                body = {
                    "model": model,
                    "messages": [
                        {"role": "system", "content": system or "你是视觉小说分镜助手。"},
                        {"role": "user", "content": text},
                    ],
                    "response_format": {"type": "json_object"},
                    "temperature": 0.7,
                    "max_tokens": 8192,
                }
                resp, status = http_post_json(DEEPSEEK_URL, body, headers, timeout=180)
                j = json.loads(resp.decode("utf-8", "ignore"))
                if "choices" not in j:
                    self._json({"code": 1, "msg": "DeepSeek 错误: " + str(j.get("error", j))}, 502)
                    return
                content = j["choices"][0]["message"]["content"]
                self._json({"code": 0, "msg": "SUCCESS", "data": content})
        except json.JSONDecodeError:
            self._json({"code": 1, "msg": "请求体不是合法 JSON"}, 400)
        except Exception as e:
            self._json({"code": 1, "msg": f"生成失败: {e}"}, 500)


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8123
    print(f"Gal Story 生图代理已启动: http://127.0.0.1:{port}")
    print("在工具的「图片工坊 -> AI 文生图」端点填写: "
          f"http://127.0.0.1:{port}/generate-image")
    print(f"生图后端: {IMAGE_BACKEND}" + ("(智谱已配置)" if ZHIPU_API_KEY else ""))
    if SECRET:
        print("Seedream 密钥: 已配置 (config.json / 环境变量)")
    else:
        print("Seedream 密钥: 未配置！请在 config.json 填写 seedream_secret 后重启")
    print(f"Token 服务: {TOKEN_URL}")
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
