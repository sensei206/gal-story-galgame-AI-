Option Explicit
Dim quiet
quiet = False
If WScript.Arguments.Count > 0 Then
  If LCase(WScript.Arguments(0)) = "quiet" Then quiet = True
End If
Sub Notify(txt, icon)
  If Not quiet Then MsgBox txt, icon, "Gal Story Proxy"
End Sub

Dim sh, exec, line, parts, pid, stopped
Set sh = CreateObject("WScript.Shell")
Set exec = sh.Exec("cmd /c netstat -ano | findstr :8123 | findstr LISTENING")
Do While exec.Status = 0
  WScript.Sleep 50
Loop

stopped = False
Do While Not exec.StdOut.AtEndOfStream
  line = Trim(exec.StdOut.ReadLine)
  parts = Split(line, " ")
  pid = parts(UBound(parts))
  If pid <> "" And IsNumeric(pid) Then
    On Error Resume Next
    sh.Run "cmd /c taskkill /F /PID " & pid, 0, True
    If Err.Number = 0 Then stopped = True
    On Error GoTo 0
  End If
Loop

If stopped Then
  Notify "������ֹͣ��", 64
Else
  Notify "û�м�⵽�����еĴ������˿� 8123 �޼�������", 48
End If