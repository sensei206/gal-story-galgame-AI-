Option Explicit
Dim quiet
quiet = False
If WScript.Arguments.Count > 0 Then
  If LCase(WScript.Arguments(0)) = "quiet" Then quiet = True
End If
Sub Notify(txt, icon)
  If Not quiet Then MsgBox txt, icon, "Gal Story Proxy"
End Sub

Dim sh, fso, exec, running, py, proj, cmd, t, pyHome, candidates, c
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' 1. project folder = script's own folder (portable, no hardcoded paths)
proj = fso.GetParentFolderName(WScript.ScriptFullName)

' 2. check if proxy already running (netstat)
Set exec = sh.Exec("cmd /c netstat -ano | findstr :8123 | findstr LISTENING")
Do While exec.Status = 0
  WScript.Sleep 50
Loop
running = Not exec.StdOut.AtEndOfStream
If running Then
  Notify "Proxy is already running (port 8123)." & vbCrLf & "If AI features still fail, refresh the page and retry.", 64
  WScript.Quit
End If

' 3. locate python: PATH first, then common install locations (portable, no machine-specific paths)
py = ""
Set exec = sh.Exec("cmd /c where python 2>nul")
Do While exec.Status = 0
  WScript.Sleep 50
Loop
If Not exec.StdOut.AtEndOfStream Then py = Trim(exec.StdOut.ReadLine())
If py = "" Then
  pyHome = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%")
  candidates = Array(pyHome & "\Programs\Python\Python311\python.exe", pyHome & "\Programs\Python\Python312\python.exe", pyHome & "\Programs\Python\Python313\python.exe", "C:\Python311\python.exe", "C:\Python312\python.exe", "C:\Python313\python.exe")
  For Each c In candidates
    If fso.FileExists(c) Then
      py = c
      Exit For
    End If
  Next
End If
If py = "" Then
  Notify "Python not found. Please install Python 3 from python.org and retry.", 48
  WScript.Quit
End If

' 4. proxy.py must sit next to this script
If Not fso.FileExists(proj & "\proxy.py") Then
  Notify "proxy.py not found. Double-click this file inside the project folder.", 48
  WScript.Quit
End If

' 5. start proxy in background (hidden console)
cmd = "cmd /c cd /d " & proj & " && " & py & " proxy.py"
sh.Run cmd, 0, False

' 6. wait up to 8s and verify
t = 0
Do
  WScript.Sleep 500
  t = t + 1
  Set exec = sh.Exec("cmd /c netstat -ano | findstr :8123 | findstr LISTENING")
  Do While exec.Status = 0
    WScript.Sleep 50
  Loop
  running = Not exec.StdOut.AtEndOfStream
Loop Until running Or t >= 16

If running Then
  Notify "Proxy started successfully!" & vbCrLf & "Refresh the page to use AI features." & vbCrLf & "(Stop it by double-clicking stop-proxy.vbs)", 64
Else
  Notify "Proxy failed to start: port 8123 did not respond within 8s.", 48
End If
