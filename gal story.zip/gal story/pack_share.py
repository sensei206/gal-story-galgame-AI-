#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gal Story 共享包打包工具
======================
把工程打包成可分享的 zip（自动排除含密钥的 config.json）。

用法:
    python pack_share.py            # 生成 Gal Story_共享包.zip
    python pack_share.py my.zip     # 指定输出文件名
"""
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else "Gal Story_共享包.zip"

# 要打包的目录 / 文件（相对 ROOT）
INCLUDE = [
    "index.html",
    "proxy.py",
    "config.example.json",
    "README.md",
    "start-proxy.bat",
    "assets",
    "docs",
]
# 绝对排除（含密钥 / 开发产物）
EXCLUDE_DIRS = {"scripts", "__pycache__", ".git", "node_modules"}
EXCLUDE_FILES = {"config.json", "pack_share.py"}

README_TXT = """Gal Story 共享包使用说明
========================

【重要】必须先解压整个压缩包，再从解压出的文件夹里打开 index.html。
直接双击压缩包内的文件会导致图片等资源丢失（显示不出图）。

1. 把本文件夹（或整个 zip）发给别人。
2. 对方操作：
   - 复制 config.example.json 为 config.json
   - 在 config.json 中填写自己的 Seedream 签名密钥
   - 运行 python proxy.py 启动生图代理
   - 双击 index.html（或用 python -m http.server 8000 后访问 localhost:8000）
3. 工具内：
   - AI 分镜：剧本模式里填自己的 DeepSeek API Key（platform.deepseek.com 获取）
   - 生图端点：图片工坊保持默认 http://127.0.0.1:8123/generate-image
4. 作品分享给玩家：用「导出发布 -> 导出 HTML 游戏」（自包含，双击即玩）。
"""


def main():
    added = 0
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as zf:
        for item in INCLUDE:
            src = os.path.join(ROOT, item)
            if not os.path.exists(src):
                print(f"  [跳过] {item} 不存在")
                continue
            if os.path.isdir(src):
                for dirpath, dirnames, filenames in os.walk(src):
                    dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
                    for fn in filenames:
                        if fn in EXCLUDE_FILES:
                            continue
                        full = os.path.join(dirpath, fn)
                        arc = os.path.relpath(full, ROOT)
                        zf.write(full, arc)
                        added += 1
                        print(f"  + {arc}")
            else:
                if os.path.basename(item) in EXCLUDE_FILES:
                    continue
                zf.write(src, item)
                added += 1
                print(f"  + {item}")
        zf.writestr("使用说明.txt", README_TXT)
        added += 1
        print("  + 使用说明.txt")
    size = os.path.getsize(OUT) / 1024
    print(f"\n完成：{OUT}（{added} 个文件，{size:.0f} KB）")
    print("已自动排除：config.json（含密钥）、scripts、pack_share.py")
    print("发给别人前请自行确认 zip 内不含你的密钥。")


if __name__ == "__main__":
    main()
