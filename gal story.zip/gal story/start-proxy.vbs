Option Explicit
' start-proxy.vbs (fixed v2)
' 1) No more flashing windows: all checks run hidden (Run + temp file), Exec is gone.
' 2) Skips the fake Microsoft Store python stub in WindowsApps (it prints
'    "Python was not found" and does nothing -> proxy never starts).
' 3) Falls back to AutoClaw's bundled python (the only real python here).
' 4) Startup output goes to proxy.log next to this script for debugging.
'
' NOTE on quoting: the command passed to HiddenOutput/start must NOT begin with
' a double quote, otherwise cmd strips quotes and breaks the redirect.

Dim quiet
quiet = False
If WScript.Arguments.Count > 0 Then
  If LCase(WScript.Arguments(0)) = "quiet" Then quiet = True
End If

Sub Notify(txt, icon)
  If Not quiet Then MsgBox txt, icon, "Gal Story Proxy"
End Sub

Dim sh, fso, proj, py, cmd, t, c, tmpDir, out, running, line, items
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
tmpDir = sh.ExpandEnvironmentStrings("%TEMP%")

' --- run a command with a HIDDEN window and return its output ---
Function HiddenOutput(cmdLine)
  Dim tmp, f, s
  tmp = tmpDir & "\gsp_" & fso.GetTempName()
  sh.Run "cmd /c " & cmdLine & " > """ & tmp & """ 2>nul", 0, True
  s = ""
  If fso.FileExists(tmp) Then
    Set f = fso.OpenTextFile(tmp, 1, False, -2)
    If Not f.AtEndOfStream Then s = f.ReadAll
    f.Close
    fso.DeleteFile tmp, True
  End If
  HiddenOutput = s
End Function

' 1. project folder = script's own folder (portable)
proj = fso.GetParentFolderName(WScript.ScriptFullName)

' 2. already running? (hidden check, no window flash)
out = HiddenOutput("netstat -ano | findstr :8123 | findstr LISTENING")
If InStr(out, "LISTENING") > 0 Then
  Notify "Proxy is already running (port 8123)." & vbCrLf & "If AI features still fail, refresh the page and retry.", 64
  WScript.Quit
End If

' 3. locate a REAL python:
'    - 'where python' results are filtered to skip the WindowsApps Store stub
'    - then common install locations
'    - then AutoClaw's bundled python (only real python on this machine)
py = ""
For Each line In Split(HiddenOutput("where python"), vbCrLf)
  line = Trim(line)
  If line <> "" And InStr(1, LCase(line), "windowsapps") = 0 And fso.FileExists(line) Then
    py = line
    Exit For
  End If
Next
If py = "" Then
  items = Array("%LOCALAPPDATA%\Programs\Python\Python311\python.exe", _
                "%LOCALAPPDATA%\Programs\Python\Python312\python.exe", _
                "%LOCALAPPDATA%\Programs\Python\Python313\python.exe", _
                "C:\Python311\python.exe", _
                "C:\Python312\python.exe", _
                "C:\Python313\python.exe", _
                "D:\AI\AutoClaw\resources\python\python.exe")
  For Each c In items
    c = sh.ExpandEnvironmentStrings(c)
    If fso.FileExists(c) Then
      py = c
      Exit For
    End If
  Next
End If
' sanity check: the selected python must actually run (catches other fakes)
If py <> "" Then
  out = HiddenOutput("call """ & py & """ -c ""import sys;print(sys.version.split()[0])""")
  If Trim(out) = "" Then py = ""
End If
If py = "" Then
  Notify "Python not found (the Microsoft Store stub in WindowsApps doesn't count)." & vbCrLf & "Install Python 3 from python.org or tell me your python.exe path.", 48
  WScript.Quit
End If

' 4. proxy.py must sit next to this script
If Not fso.FileExists(proj & "\proxy.py") Then
  Notify "proxy.py not found. Double-click this file inside the project folder.", 48
  WScript.Quit
End If

' 5. start proxy fully hidden; log output to proxy.log for debugging
cmd = "cd /d """ & proj & """ && """ & py & """ ""proxy.py"" > ""proxy.log"" 2>&1"
sh.Run "cmd /c " & cmd, 0, False

' 6. wait up to ~9s and verify (hidden checks, no flashing)
t = 0
running = False
Do
  WScript.Sleep 300
  t = t + 1
  out = HiddenOutput("netstat -ano | findstr :8123 | findstr LISTENING")
  running = InStr(out, "LISTENING") > 0
Loop Until running Or t >= 30

If running Then
  Notify "Proxy started successfully!" & vbCrLf & "Refresh the page to use AI features." & vbCrLf & "(Stop it by double-clicking stop-proxy.vbs)", 64
Else
  Notify "Proxy failed to start within 9s." & vbCrLf & "Open proxy.log (next to this script) and check the error.", 48
End If
