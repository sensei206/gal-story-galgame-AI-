Option Explicit
' stop-proxy.vbs (fixed v2): hidden execution, no flashing windows.

Dim quiet
quiet = False
If WScript.Arguments.Count > 0 Then
  If LCase(WScript.Arguments(0)) = "quiet" Then quiet = True
End If

Sub Notify(txt, icon)
  If Not quiet Then MsgBox txt, icon, "Gal Story Proxy"
End Sub

Dim sh, fso, tmpDir
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
tmpDir = sh.ExpandEnvironmentStrings("%TEMP%")

' --- run a command with a HIDDEN window and return its output ---
Function HiddenOutput(cmdLine)
  Dim tmp, f, s
  tmp = tmpDir & "\gsp_" & fso.GetTempName()
  sh.Run "cmd /c " & cmdLine & " > """ & tmp & """ 2>nul", 0, True
  s = ""
  If fso.FileExists(tmp) Then
    Set f = fso.OpenTextFile(tmp, 1, False, -2)
    If Not f.AtEndOfStream Then s = f.ReadAll
    f.Close
    fso.DeleteFile tmp, True
  End If
  HiddenOutput = s
End Function

Dim out, line, parts, pid, stopped
out = HiddenOutput("netstat -ano | findstr :8123 | findstr LISTENING")
stopped = False
For Each line In Split(out, vbCrLf)
  line = Trim(line)
  If line <> "" Then
    parts = Split(line, " ")
    pid = Trim(parts(UBound(parts)))
    If pid <> "" And IsNumeric(pid) Then
      HiddenOutput "taskkill /F /PID " & pid
      stopped = True
    End If
  End If
Next

If stopped Then
  Notify "Proxy stopped.", 64
Else
  Notify "No proxy found on port 8123 - nothing to stop.", 48
End If
