@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Gal Story 生图代理
echo ============================================
echo   Gal Story 生图代理启动中...
echo   保持本窗口开启即可使用 AI 文生图
echo   关闭本窗口 = 停止代理
echo ============================================
echo.
python proxy.py
echo.
echo 代理已退出（可能因端口被占用或 Python 未安装）。
pause
